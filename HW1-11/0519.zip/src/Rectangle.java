
public class Rectangle {
	private int		width, height;
	private int		area;
	
	public Rectangle() {}
	public Rectangle(int w) {
		width = w;
	}
	public Rectangle(int w, int h) {
		this(w);
		height = h;
		setArea();
	}
	public void Set(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void setArea() {
		area = width*height;
	}
	public String toString() {
		return "[R] 가로: "+width+", 세로: "+height+", 넓이: "+area;
	}
	public static void printRectangles(Rectangle[] r) {
		System.out.println("- RECTANGLE -------------------------");
		for(Rectangle rr: r) {
			System.out.println(rr);
		}
	}
}