public class Figures {
	public static void main(String[] args) {
		Circle	c[] = new Circle[Rand.r(5, 10)], c1[];
		Rectangle r[] = new Rectangle[Rand.r(5, 10)];
		
		for(int i=0;i < c.length;i++)
			c[i] = new Circle(Rand.r(3, 20));
		for(int i=0;i < r.length;i++)
			r[i] = new Rectangle(Rand.r(3, 20), Rand.r(3, 20));
		printFigures(c);
		printFigures(r);		
	}
	
	public static void printFigures(Circle[] c) {
		Circle.printCircles(c);
	}
	public static void printFigures(Rectangle[] c) {
		Rectangle.printRectangles(c);
	}
}