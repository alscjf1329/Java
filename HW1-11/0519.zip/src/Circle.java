public class Circle {
	private int		radius;
	private float	area;
	public final static float PI = 3.1415f;
	
	public Circle() {}

	public Circle(int r) {
		Set(r);
		setArea();
	}
	public void Set(int r) {
		radius = r;
	}
	public void setArea() {
		area = radius*radius*PI;
	}
	public String toString() {
		return "[C] 반지름: "+radius+", 넓이: "+area;
	}
	public float getArea() {
		return area;
	}
	public static void printCircles(Circle[] c) {
		System.out.println("- CIRCLE ----------------------------------");
		for(Circle cc: c) {
			System.out.println(cc);
		}
	}
}