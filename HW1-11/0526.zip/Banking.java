import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Banking {

	public static void main(String[] args) throws FileNotFoundException {
		int			size=1000, i=0;
		Account		tmp[] = new Account[size], acc[];
		Scanner		in = new Scanner(new File("A1.txt")), line;
		String		s;
		
		while(in.hasNextLine()) {
			s = in.nextLine();
			line = new Scanner(s);
			tmp[i++]= new Account(line.next(), line.next(), line.next(), line.nextLong()); 
		}
		acc = Arrays.copyOf(tmp, i);
		for(Account a:acc)	System.out.println(a);
	}
}
