public class Account {
	String	type, no, open_date;
	long	balance;
	
	public Account(String t, String n, String o, long b) {
		type = t; no = n; open_date = o; balance = b;
	}
	public String toString() {
		String	d[] = open_date.split("-");
		return String.format("[%s][%s][생성일:%s][잔액:%d]", type, no, d[0]+"년"+d[1]+"월"+d[2]+"일", balance);
	}
}
