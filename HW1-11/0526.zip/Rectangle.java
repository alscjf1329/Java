
public class Rectangle extends Figure {
	int		width, height;
	
	public Rectangle(int xx, int yy, int w) {
		super(xx, yy);
		width = w;
	}
	public Rectangle(int x, int y, int w, int h) {
		this(x,y,w);
		height = h;
		setArea();
	}
	protected void setType() {
		type = "RECTANGLE";
	}
	public void setArea() {
		area = width*height;
	}
	public String toString() {
		return String.format("[%s|X:%d,Y:%d] 가로: %d, 세로: %d, 면적: %.3f",type, x, y, width, height, area);
	}
}
