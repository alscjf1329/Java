
import java.util.Arrays;

public class Sort {
	public static final int AREA = 0;
	public static final int RADIUS = 1;
	public static final int TYPE = 2;
	
	static void swap(Circle[] n, int i, int j) {
		Circle		tmp;
		
		tmp = n[i];
		n[i] = n[i+1];
		n[i+1] = tmp;
	}
	
	static boolean Max_Last(Circle[] n, int size, int base) {
		boolean	swapped=false;
		for(int i=0;i < size;i++) {
			if( (n[i].area > n[i+1].area && base == AREA) ||
				(n[i].type.compareTo(n[i+1].type) > 0 && base == TYPE) ||
				(n[i].radius > n[i+1].radius && base == RADIUS)	) {
				swapped = true;
				swap(n, i, i+1);
			}
		}
		return swapped;
	}
	
	static Circle[] Sorting(Circle[] n, int base) {
		Circle		r[];
		
		r = Arrays.copyOf(n, n.length);
		
		for(int i=r.length-1;i > 0;i--)
			if(!Max_Last(r, i, base)) break;
		
		return r;
	}
}