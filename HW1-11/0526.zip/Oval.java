public class Oval extends Circle {
	int		w_radius;

	public Oval(int x, int y, int r, int w_r) {
		super(x, y, r);
		Set(w_r);
		setArea();
	}
	public void Set(int w_r) {
		w_radius = w_r;
	}
	protected void setType() {
		type = "OVAL";
	}
	public void setArea() {
		area = radius*w_radius*PI;
	}
	public String toString() {
		return String.format("[%s|X:%d,Y:%d] 반지름: %d, 긴지름: %d, 면적: %.3f",type, x, y, radius, w_radius, area);
	}
}
