public class Figure {
	int		x, y;
	float	area;
	String	type;
	
	public Figure(int xx, int yy) {
		x = xx; y = yy;
		setType();
	}
	protected void setType() {
		type = "FIGURE";
	}
	public String toString() {
		return String.format("[%s|X:%d,Y:%d]",type, x, y);
	}
}
