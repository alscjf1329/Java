import java.util.LinkedList;

public class People_Comp {

	public static void main(String[] args) {
		LinkedList<People> p = new LinkedList<>();
		
		for(int i=0;i < 20;i++) {
			p.add(new People(i+"_NAME", Rand.r(18, 50), (float)Rand.r(150, 200)/Rand.r(2, 3), (Rand.r(0, 1) == 0)? 'f':'m'));
		}
		for(People ps:p) {
			System.out.println(ps);
		}
	}

}

class People {
	String	name;
	int		age;
	float	weight;
	char	gender;
	
	public People(String n, int a, float w, char g) {
		name = n; age = a; weight = w; gender = g;
	}
	
	public String toString() {
		return String.format("[%s] %d살 %.2f Kg 성별=%s", name, age, weight, (gender=='f') ? "여성":"남성");
	}
}