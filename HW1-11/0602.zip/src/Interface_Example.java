public class Interface_Example {

	public static void main(String[] args) {
		EV	kona = new EV("코나");
		MotorBike harley = new MotorBike("로드 글라이더");
		kona.print();
		harley.print();
	}

}
interface Operation {
	int		SpeedLimit = 110;
	public abstract void	Drive();
	void	Sound();
	default void	Tell() {
		System.out.println("\t동작 방식은?");
	}
}

interface Design {
	int		Max_Designers = 10;
	String	WheelSize();
	String[] Designers();
	default void	Tell() {
		System.out.println("\t설계 원칙은?");
	}
}

abstract class Vehicle {
	int		wheels;
	int		maxSpeed;
	
	String Spec(String model, String w) {
		return String.format("%s의 바퀴(%s inch)는 %d개 이고, 최대속도는 %d Km/h입니다." , 
				model,w, wheels,maxSpeed);
	}
	public abstract void print();
}

class EV extends Vehicle implements Operation, Design {
	String	model;
	
	public EV(String m) {
		model = m;
		wheels = 4;
		maxSpeed = 200;
	}
	public void	Drive() {
		System.out.println(model+"는 전기자동차입니다.");
	}
	public void	Sound() {
		System.out.println(model+"는 '위이잉'하는 소리가 납니다.");
	}
	public void print() {
		System.out.printf("%s [디자이너들] ", Spec(model, WheelSize()));
		for(String n:Designers()) System.out.print(n+", ");
		System.out.println();
		Tell();
	}
	public String WheelSize() {
		return "20";
	}
	public String[] Designers() {
		String[] n = {"HONG", "KIM", "LEE"};
		return n;
	}
}
class MotorBike extends Vehicle implements Operation {
	String	model;
	
	public MotorBike(String m) {
		model = m;
		wheels = 2;
		maxSpeed = 300;
	}
	public void	Drive() {
		System.out.println(model+"는 오토바이입니다.");
	}
	public void	Sound() {
		System.out.println(model+"는 '부르릉'하는 소리가 납니다.");
	}
	public void print() {
		System.out.printf("%s\n", Spec(model, "16"));
		Tell();
	}
}