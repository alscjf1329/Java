public class Anonymous {

	public static void main(String[] args) {
	}
}

interface Automobile {
	int		wheels = 4;
	
	void	PowerSource(String f) ;
	//void	Print(String f);
}

abstract class Ship {
	int		motors;
	
	abstract void	FuelSource() ;
	public void Size(int s) {
		System.out.println("이 배의 길이는 "+s+" 미터입니다.");
	}
}
