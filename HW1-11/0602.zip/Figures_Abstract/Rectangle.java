
public class Rectangle extends Figure {
	int		width, height;
	
	public Rectangle(int xx, int yy, int w) {
		super(xx, yy);
		width = w;
	}
	public Rectangle(int x, int y, int w, int h) {
		this(x,y,w);
		height = h;
		setArea();
	}
	protected void setType() {
		type = "RECTANGLE";
	}
	public void setArea() {
		area = width*height;
	}
	public String toString() {
		String tmp = super.toString();
		
		if((this instanceof Rectangle) && !(this instanceof Triangle))
			tmp += String.format(" 가로: %d, 세로: %d", width, height);
		else
			tmp += String.format(" 밑변: %d, 높이: %d", width, height);
		
		return String.format("%s, 면적: %.3f",tmp, area);
	}
}
