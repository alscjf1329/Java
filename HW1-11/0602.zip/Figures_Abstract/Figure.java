public abstract class Figure {
	int		x, y;
	float	area;
	String	type;
	
	public Figure(int xx, int yy) {
		x = xx; y = yy;
		setType();
	}
	protected abstract void setType() ;
	protected abstract void setArea() ;
	
	public String toString() {
		return String.format("[%s|X:%d,Y:%d]",type, x, y);
	}
}
