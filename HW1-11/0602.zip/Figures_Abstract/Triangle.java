
public class Triangle extends Rectangle {
	public Triangle(int x, int y, int w, int h) {
		super(x, y,w,h);
		//setArea();
	}
	protected void setType() {
		type = "TRIANGLE";
	}
	public void setArea() {
		area = width*height/2.0f;
	}
	/*
	public String toString() {
		return String.format("[%s|X:%d,Y:%d] 가로: %d, 세로: %d, 면적: %.3f",type, x, y, width, height, area);
	}
	*/
}
