import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Figures {
	public static void main(String[] args) throws FileNotFoundException {
		int			size=1000, i=0;
		Figure		tmp[] = new Figure[size], f[], sorted[];
		Scanner		in = new Scanner(new File("Fig1.txt")), line;
		String		s, type;
		
		while(in.hasNextLine()) {
			s = in.nextLine();
			line = new Scanner(s);
			type = line.next();
			switch (type) {
			case "원":
				tmp[i++] = new Circle(line.nextInt(), line.nextInt(), line.nextInt());
				break;
			case "타원":
				tmp[i++] = new Oval(line.nextInt(), line.nextInt(), line.nextInt(), line.nextInt());
				break;
			case "사각형":
				tmp[i++] = new Rectangle(line.nextInt(), line.nextInt(), line.nextInt(), line.nextInt());
				break;
			default:
				break;
			}
		}
		f = Arrays.copyOf(tmp, i);
		sorted = Sort.Sorting(f, Sort.AREA);
		for(Figure fig:sorted) System.out.println(fig);
	}
}
