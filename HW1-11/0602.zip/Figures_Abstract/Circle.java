public class Circle extends Figure {
	int		radius = -1;
	public final static float PI = 3.1415f;

	public Circle(int x, int y, int r) {
		super(x, y);
		//Set(r);
		radius = r;
		setArea();
	}
	public void Set(int r) {
		radius = r;
	}
	protected void setType() {
		type = "CIRCLE";
	}
	public void setArea() {
		area = radius*radius*PI;
	}
	public String toString() {
		String tmp = "";
		
		if((this instanceof Circle) && !(this instanceof Oval))
			tmp = String.format(", 면적: %.3f", area);
		return String.format("%s 반지름: %d%s",super.toString(), radius,tmp);
	}
}
