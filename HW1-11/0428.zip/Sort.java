import java.util.Arrays;

public class Sort {
	static void PrintNum(int[] n, int size) {
		for(int i=0;i < n.length;i++) {
			System.out.printf("%3d ", n[i]);
			if( (i+1) % size == 0) System.out.println();
		}
	}
	
	static void swap(int[] n, int i, int j) {
		int		tmp;
		
		tmp = n[i];
		n[i] = n[i+1];
		n[i+1] = tmp;
	}
	
	static boolean Max_Last(int[] n, int size) {
		boolean	swapped=false;
		for(int i=0;i < size;i++) {
			if(n[i] > n[i+1]) {
				swapped = true;
				swap(n, i, i+1);
			}
		}
		return swapped;
	}
	
	static int[] Sorting(int[] n) {
		int		r[];
		
		r = Arrays.copyOf(n, n.length);
		
		for(int i=r.length-1;i > 0;i--)
			if(!Max_Last(r, i)) break;
		
		return r;
	}
}