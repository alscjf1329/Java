public class InPackage {

	public static void main(String[] args) {
		final short a1 = (short)0b0000000000000001;	// 연필
		final short a2 = (short)0b0000000000000010;	// 네임펜
		final short a3 = (short)0b0000000000000100;	// 칼
		final short a4 = (short)0b0000000000001000;	// 가위
		final short a5 = (short)0b0000000000010000;	// 테이프
		final short a6 = (short)0b0000000000100000;	// 포스트잇
		final short a7 = (short)0b0000000001000000;	// 샤프
		final short a8 = (short)0b0000000010000000;	// 크레용
		final short a9 = (short)0b0000000100000000;	// A4용지
		final short a10 =(short)0b0000001000000000;	// 지우개  

		short	pack = 23;
		
		if( (pack & a1) > 0 )  System.out.print(":연필");
		if( (pack & a2) > 0 )  System.out.print(":네임펜");
		if( (pack & a3) > 0 )  System.out.print(":칼");
		if( (pack & a4) > 0 )  System.out.print(":가위");
		if( (pack & a5) > 0 )  System.out.print(":테이프");
		if( (pack & a6) > 0 )  System.out.print(":포스트잇");
		if( (pack & a7) > 0 )  System.out.print(":샤프");
		if( (pack & a8) > 0 )  System.out.print(":크레용");
		if( (pack & a9) > 0 )  System.out.print(":A4용지");
		if( (pack & a10) > 0 )  System.out.print(":지우개");
		System.out.println(":");
	}
}