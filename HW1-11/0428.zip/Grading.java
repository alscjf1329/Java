import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Grading {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner	in = new Scanner(new File("1_10.txt"));
		final int	SIZE = 100;
		String[]	number, name, t_num = new String[SIZE], t_name = new String[SIZE];
		int[]		kor, eng, math, k = new int[SIZE], e = new int[SIZE], m = new int[SIZE];
		float[]		avg;
		int			idx=0;
		
		while(in.hasNext()) {
			t_num[idx] = in.next();
			t_name[idx] = in.next();
			k[idx] = in.nextInt();
			e[idx] = in.nextInt();
			m[idx] = in.nextInt();
			idx++;
		}
		number = Arrays.copyOf(t_num, idx);
		name = Arrays.copyOf(t_name, idx);
		kor = Arrays.copyOf(k, idx);
		eng = Arrays.copyOf(e, idx);
		math = Arrays.copyOf(m, idx);
		avg = new float[idx];
		
		for(int i=0;i < idx;i++) {
			System.out.printf("[%2d] %s %s %2d %2d %2d %.2f\n", i+1, number[i], name[i], kor[i], eng[i], math[i], 
					(avg[i] = (kor[i]+eng[i]+math[i])/3.0f));
		}
	}
}
